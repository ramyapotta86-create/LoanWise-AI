# PROJECT SCHEMA — LOANWISE AI

**Title:** LoanWise AI – An Explainable AI-Powered Loan Eligibility & Risk Assessment System  
**Academic Level:** First-Year AI & ML Capstone Project (3 Team Members)  
**Document Status:** Finalized Blueprint (Pre-Implementation)  
**Last Updated:** 2026-11-25  

> **Verification & Honesty Notice:**  
> This blueprint strictly separates **confirmed facts**, **publicly listed metadata (pending local inspection)**, **assumptions**, and **architectural recommendations**. No application code has been written yet, no Kaggle CSVs have been inspected locally in this workspace yet, and **no model evaluation metrics are claimed or fabricated**.

---

## 1. Executive Summary & Project Goals

LoanWise AI solves the college-assigned **Loan Approval Eligibility Checker** problem while elevating it with clean software engineering, leak-free scikit-learn pipelines, REST API serving, and Explainable AI (SHAP):

1. **Reliable Baseline Modeling:** Use the assigned Kaggle Loan Prediction Problem Dataset as the sole primary training source after local CSV verification.
2. **Leak-Free ML Engineering:** Encapsulate imputation, encoding, scaling, and feature engineering inside scikit-learn `Pipeline` and `ColumnTransformer` objects trained strictly offline.
3. **Explainability & Responsibility:** Pair predictions with SHAP-based feature contributions, demographic sensitivity checks (`Gender`, `Married`), a human-review confidence zone, and strict non-PII logging.
4. **Accessible Full-Stack Architecture:** Serve predictions via FastAPI (`POST /predict`, `POST /explain`, `GET /history`, `GET /model-info`) to a clean 6-page Streamlit interface backed by SQLite.
5. **Balanced 3-Person Delivery:** Divide ML, Backend, and Frontend cleanly while requiring shared ownership of testing, documentation, GitHub PRs, and final presentation.

---

## 2. Fact vs. Assumption vs. Recommendation Register

| Item | Classification | Details |
| :--- | :--- | :--- |
| Workspace state | **Confirmed Fact** | `d:\Loan prediction` contained no source code, datasets, or pre-existing docs at blueprint creation. |
| Primary dataset assignment | **Confirmed Requirement** | Assigned dataset is `altruistdelhite04/loan-prediction-problem-dataset` on Kaggle; external datasets are optional if justified. |
| Primary dataset schema & counts | **Public Metadata (Pending Local Verification)** | Publicly described as ~614 train rows (13 columns including `Loan_Status`) and ~367 test rows (12 columns without `Loan_Status`). Exact file names, casing, missing counts, and license text must be verified after local download. |
| Supplementary dataset (`architsharma01`) | **Public Metadata (Pending Local Verification)** | Publicly listed as 4,269 rows, 13 columns, MIT License, using `cibil_score`, `income_annum`, and asset columns. |
| Dataset combination decision | **Architectural Decision** | **Do not merge** the primary and supplementary datasets because schemas, credit-score definitions, income periods, and asset features are incompatible. Keep supplementary dataset strictly optional as an independent comparative notebook experiment. |
| Model performance & winner | **Pending Experimentation** | Logistic Regression, Decision Tree, and Random Forest will be benchmarked on identical stratified CV/test splits; no model is pre-declared "best". |

---

## 3. Dataset Strategy Summary

*(Full details in [docs/DATASET_STRATEGY.md](file:///d:/Loan%20prediction/docs/DATASET_STRATEGY.md))*

### 3.1 Primary Model Features (11 Inputs + 1 Target, `Loan_ID` Excluded)

| Feature | Expected Type | Expected Values / Units *(Verify Locally)* | Training Role |
| :--- | :--- | :--- | :--- |
| `Loan_ID` | String ID | Unique identifier (e.g., `LP001002`) | **Excluded** (non-predictive identifier) |
| `Gender` | Categorical | `Male`, `Female` | Input feature (also audited in Responsible AI ablation) |
| `Married` | Categorical | `Yes`, `No` | Input feature (also audited in Responsible AI ablation) |
| `Dependents` | Ordinal / Categorical | `0`, `1`, `2`, `3+` | Input feature (`3+` mapped to `3` in pipeline) |
| `Education` | Categorical | `Graduate`, `Not Graduate` | Input feature |
| `Self_Employed` | Categorical | `Yes`, `No` | Input feature |
| `ApplicantIncome` | Numerical | Non-negative monetary amount *(verify period)* | Input feature |
| `CoapplicantIncome` | Numerical | Non-negative monetary amount *(verify period)* | Input feature |
| `LoanAmount` | Numerical | Positive monetary amount *(commonly thousands — verify)* | Input feature |
| `Loan_Amount_Term` | Numerical | Positive integer *(commonly months, e.g., 360)* | Input feature |
| `Credit_History` | Binary Numerical | `1` (meets guidelines), `0` (does not) | Input feature |
| `Property_Area` | Categorical | `Urban`, `Semiurban`, `Rural` *(verify exact spelling)* | Input feature |
| `Loan_Status` | Target (Train CSV only) | `Y` (Approved → `1`), `N` (Rejected → `0`) | Supervised target |

### 3.2 Critical Evaluation Split Rule
Public Kaggle listings indicate the **test CSV (~367 rows) has no `Loan_Status` column**. Therefore:
- Model training, validation, and final test evaluation **must** come from a **stratified split of the labeled training CSV (~614 rows)** (e.g., 80% development / 20% held-out test, with 5-fold Stratified Cross-Validation inside the 80% development set).
- The unlabeled Kaggle test CSV can only be used for optional inference sanity checks, never for computing accuracy, F1, or ROC-AUC.

---

## 4. Machine Learning Pipeline Summary

*(Full details in [docs/ML_METHODOLOGY.md](file:///d:/Loan%20prediction/docs/ML_METHODOLOGY.md))*

1. **Leak-Free Preprocessing (`ColumnTransformer` + `Pipeline`):**
   - Custom stateless transformer: strips whitespace on string columns, converts `Dependents` (`"3+"` → `3`), and engineers `TotalIncome = ApplicantIncome + CoapplicantIncome`.
   - Numerical pipeline: `SimpleImputer(strategy="median")` + `StandardScaler()` (for Logistic Regression; tree models work with or without scaling, kept consistent or branched cleanly per model).
   - Categorical pipeline: `SimpleImputer(strategy="most_frequent")` + `OneHotEncoder(handle_unknown="ignore", drop=None)`.
2. **Additional Ratios:** Only add ratios like `LoanAmount_to_TotalIncome` after EDA confirms consistent units across `LoanAmount` and `ApplicantIncome`. Never fabricate annual income or existing debt payments.
3. **Candidate Models:**
   - `LogisticRegression` (interpretable linear baseline, `class_weight` evaluated during imbalance analysis).
   - `DecisionTreeClassifier` (non-linear rule baseline with bounded `max_depth`).
   - `RandomForestClassifier` (ensemble baseline with controlled depth/estimators to prevent overfitting on ~614 rows).
4. **Evaluation Metrics:** Accuracy, Precision, Recall, F1-score, Confusion Matrix (with FP/FN financial risk discussion), and ROC-AUC.
5. **Explainability:** SHAP (`LinearExplainer` for Logistic Regression or `TreeExplainer` for tree models) mapped to transformed feature names and grouped back to human-readable inputs.

---

## 5. System & API Architecture Summary

*(Full details in [docs/SYSTEM_ARCHITECTURE.md](file:///d:/Loan%20prediction/docs/SYSTEM_ARCHITECTURE.md) and [docs/API_SPECIFICATION.md](file:///d:/Loan%20prediction/docs/API_SPECIFICATION.md))*

- **Offline Workflow:** Raw CSV → Inspection & EDA → Preprocessing + Feature Engineering → Stratified Split & CV → Model Comparison → Tuning (only if justified on CV) → Final Evaluation on Held-Out Test → Serialize `model_pipeline.joblib` + `model_metadata.json`.
- **Online Workflow:** Streamlit UI → FastAPI Pydantic validation → Loaded `model_pipeline.joblib` → Prediction + Confidence + Human-Review Flag → Optional SQLite non-PII logging → SHAP Explanation via `POST /explain` → Interactive UI rendering.
- **Endpoints (Strictly Purpose-Driven):**
  - `GET /` — Health check & loaded model status
  - `POST /predict` — Returns prediction, approval probability, risk/confidence band, human-review flag, disclaimer, and assessment ID
  - `POST /explain` — Returns SHAP base value, per-feature contributions, top positive/negative factors, and plain-language summary
  - `GET /history` — Lists paginated, filterable non-PII assessment history from SQLite
  - `GET /model-info` — Returns selected algorithm, version, dataset info, feature schema, and measured metrics

---

## 6. Application UI Pages (Streamlit)

1. **Dashboard (`app.py`):** Project overview, offline/online workflow summary, verified dataset statistics, model performance summary, navigation cards.
2. **Loan Eligibility Assessment (`pages/1_Loan_Assessment.py`):** Clean form accepting **only** the 11 model-supported inputs with valid bounds, help text, and unit labels.
3. **Prediction Results (`pages/2_Prediction_Results.py`):** Eligibility decision, probability gauge (Plotly) explained as historical-data likelihood (not a guarantee), human-review alert for borderline scores (`0.40 <= p <= 0.60`), input summary, and disclaimer.
4. **Explainable AI (`pages/3_Explainable_AI.py`):** Global feature importance + local SHAP positive/negative contribution chart (Plotly) + plain-language explanation + attribution-vs-causation note.
5. **Assessment History (`pages/4_Assessment_History.py`):** Filterable table of past non-PII predictions fetched from `GET /history`.
6. **Model Information (`pages/5_Model_Information.py`):** Selected model, version, training metadata, evaluation metrics table, and Responsible AI highlights fetched from `GET /model-info`.

---

## 7. Team, GitHub & Roadmap Alignment

- **Team Split ([docs/TEAM_RESPONSIBILITIES.md](file:///d:/Loan%20prediction/docs/TEAM_RESPONSIBILITIES.md)):**
  - **Member 1:** Data Verification, EDA, Preprocessing & ML Modeling (`ml/`, `notebooks/`).
  - **Member 2:** FastAPI Backend, SQLite History & SHAP API (`backend/`, `database/`).
  - **Member 3:** Streamlit Frontend, Plotly Visuals & End-to-End Integration (`frontend/`).
  - **Shared:** Unit/API testing (`tests/`), documentation updates, PR reviews, final slide deck & demo.
- **GitHub Workflow ([docs/GITHUB_WORKFLOW.md](file:///d:/Loan%20prediction/docs/GITHUB_WORKFLOW.md)):** `main` (demo-ready) ← `develop` (integration) ← `feature/data-cleaning`, `feature/model-training`, `feature/backend-api`, `feature/frontend-ui`. Large raw CSVs, `.joblib` artifacts, and `.db` files stay out of Git via `.gitignore`.
- **12-Step Roadmap ([docs/IMPLEMENTATION_ROADMAP.md](file:///d:/Loan%20prediction/docs/IMPLEMENTATION_ROADMAP.md)):** Sequential and parallel milestones with explicit integration gates before connecting ML → Backend → Frontend.

---

## 8. Cross-Document Consistency Checklist

- Every input field in Streamlit matches Pydantic schemas in `API_SPECIFICATION.md`, which match the 11 features in `ML_METHODOLOGY.md` and `DATASET_STRATEGY.md`.
- `Loan_ID` is excluded from training, API prediction requests, and SQLite storage.
- No PII (names, phone numbers, addresses, emails) is collected or stored anywhere in the system.
- All 10 deliverables are complete, consistent, and ready for Phase 1 implementation.
