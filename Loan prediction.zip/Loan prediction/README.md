# LoanWise AI — Explainable AI-Powered Loan Eligibility & Risk Assessment System

> **Status:** Blueprint & Documentation Phase (Architecture Finalized — Application Code Not Yet Implemented)  
> **Project Type:** First-Year AI & ML Capstone Project (3-Member Student Team)  
> **Disclaimer:** LoanWise AI is an **educational prototype** built on historical public datasets. Predictions and explainability outputs are statistical estimates for academic demonstration only and **do not constitute real banking, credit, or financial approval decisions**.

---

## 1. Project Overview

**LoanWise AI** is an end-to-end machine learning web application that estimates loan application eligibility (`Approved` vs. `Rejected`) and explains the key model drivers behind each prediction using Explainable AI (SHAP).

Designed specifically to be **technically sound, reproducible, and manageable for first-year AI & ML students**, the system separates:
- **Offline ML Training Pipeline** (data inspection, preprocessing, feature engineering, stratified evaluation, model comparison, serialization).
- **Online Prediction & Explanation Service** (FastAPI REST backend + SQLite non-PII assessment history + Streamlit interactive frontend).

---

## 2. Core Technology Stack

| Layer | Technologies | Purpose |
| :--- | :--- | :--- |
| **Frontend** | Streamlit, Custom CSS, Plotly | Interactive 6-page UI, applicant form, probability gauges, SHAP bar charts |
| **Backend** | FastAPI, Pydantic, Uvicorn | Input validation, REST endpoints, model inference, SHAP explanation service |
| **Machine Learning** | Python, Pandas, NumPy, Scikit-learn, SHAP, Joblib | Leak-free preprocessing (`Pipeline` + `ColumnTransformer`), model training, explainability, serialization |
| **Database** | SQLite | Lightweight local storage for non-PII assessment history |
| **Tooling** | VS Code, Jupyter Notebook, Git, GitHub, Pytest | EDA experimentation, version control, team collaboration, automated testing |

---

## 3. Documentation Index

All finalized project blueprint documents live in the repository root and the `docs/` directory:

| Document | Path | Summary |
| :--- | :--- | :--- |
| **Master Project Schema** | [PROJECT_SCHEMA.md](file:///d:/Loan%20prediction/PROJECT_SCHEMA.md) | Complete project blueprint tying all requirements, contracts, and decisions together |
| **System Architecture** | [docs/SYSTEM_ARCHITECTURE.md](file:///d:/Loan%20prediction/docs/SYSTEM_ARCHITECTURE.md) | Offline training vs. online inference architecture, Mermaid diagrams, tech rationale |
| **Dataset Strategy** | [docs/DATASET_STRATEGY.md](file:///d:/Loan%20prediction/docs/DATASET_STRATEGY.md) | Primary dataset spec, supplementary dataset compatibility audit, verification checklist |
| **ML Methodology** | [docs/ML_METHODOLOGY.md](file:///d:/Loan%20prediction/docs/ML_METHODOLOGY.md) | 16-step pipeline, preprocessing, feature engineering, model comparison, metrics, SHAP |
| **API Specification** | [docs/API_SPECIFICATION.md](file:///d:/Loan%20prediction/docs/API_SPECIFICATION.md) | FastAPI endpoints, Pydantic schemas, validation rules, error handling, SQLite schema |
| **Folder Structure** | [docs/FOLDER_STRUCTURE.md](file:///d:/Loan%20prediction/docs/FOLDER_STRUCTURE.md) | Complete directory layout, file responsibilities, `.gitignore` & artifact instructions |
| **Team Responsibilities** | [docs/TEAM_RESPONSIBILITIES.md](file:///d:/Loan%20prediction/docs/TEAM_RESPONSIBILITIES.md) | 3-member workload split, shared tasks, integration ownership, viva readiness |
| **GitHub Workflow** | [docs/GITHUB_WORKFLOW.md](file:///d:/Loan%20prediction/docs/GITHUB_WORKFLOW.md) | Branching strategy, commit standards, PR reviews, merge rules |
| **Implementation Roadmap** | [docs/IMPLEMENTATION_ROADMAP.md](file:///d:/Loan%20prediction/docs/IMPLEMENTATION_ROADMAP.md) | 12-step execution plan, task dependencies, definition of done |
| **Responsible AI** | [docs/RESPONSIBLE_AI.md](file:///d:/Loan%20prediction/docs/RESPONSIBLE_AI.md) | Bias risks, demographic sensitivity checks, human-in-the-loop band, privacy & ethics |

---

## 4. Dataset Attribution & Verification Status

- **Primary Dataset (Assigned):** [Loan Prediction Problem Dataset](https://www.kaggle.com/datasets/altruistdelhite04/loan-prediction-problem-dataset) (Kaggle / `altruistdelhite04`).
- **Supplementary Candidate (Evaluated Separately):** [Loan Approval Prediction Dataset](https://www.kaggle.com/datasets/architsharma01/loan-approval-prediction-dataset) (Kaggle / `architsharma01`).
- **Verification Status:** Public dataset metadata has been reviewed, **local CSV files have not yet been downloaded or inspected**, and **no datasets are combined**. All raw CSVs remain excluded from Git via `.gitignore`; see [docs/DATASET_STRATEGY.md](file:///d:/Loan%20prediction/docs/DATASET_STRATEGY.md) for the download and inspection checklist.

---

## 5. Planned Execution Flow (Once Implementation Begins)

1. Follow [docs/IMPLEMENTATION_ROADMAP.md](file:///d:/Loan%20prediction/docs/IMPLEMENTATION_ROADMAP.md) Phase 1 to scaffold the folders, `.gitignore`, and `requirements.txt`.
2. Download and inspect the primary Kaggle dataset locally before writing preprocessing code.
3. Run offline training (`ml/train.py`) to compare Logistic Regression, Decision Tree, and Random Forest and export the winning model bundle (`models/`).
4. Start the FastAPI backend (`uvicorn backend.main:app --reload`) and Streamlit frontend (`streamlit run frontend/app.py`).
