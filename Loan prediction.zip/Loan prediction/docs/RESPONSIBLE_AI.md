# RESPONSIBLE AI & ETHICAL GOVERNANCE — LOANWISE AI

**Document Version:** 1.0 (Finalized Blueprint)  
**Related Docs:** [PROJECT_SCHEMA.md](file:///d:/Loan%20prediction/PROJECT_SCHEMA.md) | [docs/ML_METHODOLOGY.md](file:///d:/Loan%20prediction/docs/ML_METHODOLOGY.md) | [docs/API_SPECIFICATION.md](file:///d:/Loan%20prediction/docs/API_SPECIFICATION.md)

---

## 1. Educational Prototype Disclaimer

> **LoanWise AI is an academic, first-year AI & ML educational prototype.**  
> Its predictions and SHAP explanations are statistical estimates derived from a small historical public dataset (~614 records). It is **not** a certified credit-scoring engine, **not** connected to any bank or credit bureau, and must **never** be presented or used as an automated financial approval authority.

This disclaimer must appear visibly on:
- The Streamlit Dashboard, Prediction Results page, Explainable AI page, and Model Information page.
- Every `POST /predict` API response (`disclaimer` field).
- Every `POST /explain` API response (`causation_notice` field).

---

## 2. Historical Bias & Sensitive Demographic Attributes

Historical loan approval datasets frequently reflect past human underwriting patterns, socioeconomic disparities, or sampling imbalances rather than purely objective repayment ability.

In the primary Kaggle dataset, two demographic columns require explicit ethical scrutiny:
- `Gender` (`Male`, `Female`)
- `Married` (`Yes`, `No`)

### 2.1 Mandatory Demographic Ablation Experiment (`ml/fairness.py`)
During Phase 5 (Model Evaluation), Member 1 will evaluate **both** configurations using the exact same stratified split and winning algorithm:
- **Model A (Full Baseline):** Trained with all 11 primary features (`Gender` and `Married` included).
- **Model B (Fairness-Ablated):** Trained **without** `Gender` and `Married` (9 raw features + `TotalIncome`).

**Decision Rule:**
- Measure Accuracy, F1, ROC-AUC, and group-level approval rates / false-negative rates across `Gender` and `Married` subgroups for both Model A and Model B.
- If removing `Gender` and `Married` maintains comparable predictive performance (e.g., within ~1–2% F1/ROC-AUC) while reducing demographic disparity, **document the finding clearly** and recommend Model B (or display the exact trade-off on the Model Information page). Even if Model A is kept for exact assignment schema parity, the ablation comparison table **must** be documented and presented.

---

## 3. Fairness Checks to Measure & Report

In `ml/fairness.py` (executed on the 20% held-out test set after training):

1. **Subgroup Distribution Inspection:** Report sample count and baseline approval rate per `Gender` (`Male` vs. `Female`) and `Married` (`Yes` vs. `No`) in the training set.
2. **Demographic Parity Difference (DPD):**
   $$\text{DPD} = |P(\hat{Y}=1 \mid \text{Group A}) - P(\hat{Y}=1 \mid \text{Group B})|$$
   Measures whether positive prediction rates differ sharply across demographic subgroups.
3. **Equal Opportunity Difference (EOD / True Positive Rate Gap):**
   $$\text{EOD} = |\text{TPR}_{\text{Group A}} - \text{TPR}_{\text{Group B}}|$$
   Measures whether genuinely creditworthy (`Y`) applicants receive equal approval rates across groups.
4. **Honesty Rule:** Report small-sample caveats (especially if one subgroup, such as `Female` applicants, has far fewer test samples in a 20% split of ~614 rows).

---

## 4. Transparent Explanations (Attribution vs. Causation)

- **What SHAP Tells Us:** How much each input feature pushed the **model's** probability score upward or downward relative to the average training-set baseline.
- **What SHAP Does NOT Tell Us:** Why a real human loan officer approved or rejected an application, or whether changing one attribute (like marital status) would causally change real-world creditworthiness.
- **Plain-Language Guardrails:** The Explainable AI page will translate SHAP values into clear, hedged language (e.g., *"In this historical model, `Credit_History = 1` moved the prediction score higher"* rather than *"The bank approved your loan because..."*).

---

## 5. Human-in-the-Loop (HITL) Review for Uncertain Predictions

Automated binary decisions near the 50% decision threshold carry the highest risk of False Positives and False Negatives.

- **Borderline Review Band:** Any prediction with approval probability $0.40 \le p \le 0.60$ is flagged with `human_review_recommended: true` and `confidence_band: "Uncertain / Borderline"`.
- **UI Behavior:** The Streamlit Results page displays an explicit amber advisory banner: *"Borderline model confidence — manual underwriting / human review is strongly recommended."*
- **Probability Interpretation:** Probabilities are explicitly labeled as **statistical model confidence scores based on historical training data**, never as a guarantee of loan approval or rejection.

---

## 6. Data Privacy & Minimization

1. **No Personally Identifiable Information (PII):** The application **never** asks for or stores applicant names, addresses, phone numbers, email addresses, government IDs, bank account numbers, or `Loan_ID`.
2. **Minimal SQLite History:** `database/loanwise.db` stores only anonymous numerical/categorical model inputs, timestamps, prediction outputs, and model version so evaluators can test the Assessment History feature without privacy risk.
3. **Local-Only Storage:** Both SQLite and raw datasets remain local to the developer machine and are excluded from GitHub via `.gitignore`.
