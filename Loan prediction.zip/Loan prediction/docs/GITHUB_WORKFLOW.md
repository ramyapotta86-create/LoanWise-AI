# GITHUB COLLABORATION WORKFLOW — LOANWISE AI

**Document Version:** 1.0 (Finalized Blueprint)  
**Related Docs:** [docs/FOLDER_STRUCTURE.md](file:///d:/Loan%20prediction/docs/FOLDER_STRUCTURE.md) | [docs/TEAM_RESPONSIBILITIES.md](file:///d:/Loan%20prediction/docs/TEAM_RESPONSIBILITIES.md) | [docs/IMPLEMENTATION_ROADMAP.md](file:///d:/Loan%20prediction/docs/IMPLEMENTATION_ROADMAP.md)

---

## 1. Branching Strategy (Simple & Safe for 3 Students)

```text
main (protected: always stable, demo-ready)
 └── develop (integration branch where completed features meet)
      ├── feature/data-cleaning      (Member 1: inspection, EDA, preprocess.py)
      ├── feature/model-training     (Member 1: train.py, evaluate.py, explain.py, fairness.py)
      ├── feature/backend-api        (Member 2: FastAPI routers, schemas, SQLite, SHAP service)
      └── feature/frontend-ui        (Member 3: Streamlit 6 pages, Plotly charts, CSS, API client)
```

### Branch Rules
1. **`main`:** Never push directly to `main`. Merge only from `develop` after tests pass and the full demo runs cleanly.
2. **`develop`:** Integration branch created from `main`. Feature branches merge here via Pull Requests.
3. **Feature Branches:** Named `feature/<topic>` (or `docs/<topic>`, `fix/<topic>` when needed). Delete merged feature branches or keep them tidy after PR merge.

---

## 2. Step-by-Step Git Commands for Team Members

### Initial Clone & Setup
```bash
git clone <repository-url>
cd loanwise-ai
git checkout develop
git pull origin develop
```

### Creating a Feature Branch
```bash
git checkout develop
git pull origin develop
git checkout -b feature/backend-api
```

### Staging & Committing Meaningful Changes
```bash
git status
git add backend/routers/predict.py backend/schemas/loan.py
git commit -m "feat(backend): add POST /predict endpoint with Pydantic validation"
```

### Syncing Before Opening a Pull Request
```bash
git checkout develop
git pull origin develop
git checkout feature/backend-api
git merge develop
# Resolve any conflicts locally, run pytest, then push:
git push -u origin feature/backend-api
```

---

## 3. Commit Message Convention

Use clean, descriptive **Conventional Commits** (`<type>(<scope>): <short summary>`):

| Prefix | When to Use | Example |
| :--- | :--- | :--- |
| `feat` | New feature or module | `feat(ml): add stratified CV pipeline in train.py` |
| `fix` | Bug fix | `fix(api): handle missing Dependents value in predictor` |
| `docs` | Documentation updates | `docs(ml): record verified CV and test metrics` |
| `test` | Adding or updating tests | `test(api): add validation tests for negative LoanAmount` |
| `style` | CSS or formatting only | `style(ui): refine prediction badge spacing in styles.css` |
| `chore` | Repo setup, `.gitignore`, deps | `chore(setup): add requirements.txt and .gitignore` |

**Avoid vague commits** like `"update"`, `"fixed"`, or `"final code"`.

---

## 4. Pull Request (PR) & Code Review Rules

1. **Small, Focused PRs:** Open a PR from `feature/*` → `develop` as soon as a logical milestone works (do not wait until the final week to merge everything at once).
2. **Minimum 1 Peer Review:** At least **one other teammate** must review and approve the PR on GitHub before merging.
3. **PR Checklist (Must Be True Before Approval):**
   - [ ] Code follows [PROJECT_SCHEMA.md](file:///d:/Loan%20prediction/PROJECT_SCHEMA.md) feature names and API contracts.
   - [ ] No raw CSV files, `.joblib` binaries, `.db` files, or `.venv/` folders are tracked in the diff.
   - [ ] Existing `pytest` tests pass (`pytest -v`).
   - [ ] New functions have clear docstrings and no hardcoded local absolute paths (`C:\Users\...`).
4. **Merge Method:** Use **Squash and Merge** or **Merge Commit** (`--no-ff`) on `feature/*` → `develop` so commit history stays readable; use a **Merge Commit** from `develop` → `main` at verified demo milestones.

---

## 5. Repository Hygiene Reminders

- **Never commit large datasets or `.joblib` models:** Check `git status` before `git add .` (or avoid `git add .` blindly and stage specific paths).
- **Check `.gitignore` first:** Verify `.gitignore` is committed in Phase 1 before anyone downloads CSVs into `data/raw/` or runs `ml/train.py`.
- **Use relative paths via `config/settings.py`:** Never hardcode `D:\Users\...` paths inside code so all 3 laptops run identically.
