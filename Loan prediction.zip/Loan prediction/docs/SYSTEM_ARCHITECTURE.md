# SYSTEM ARCHITECTURE — LOANWISE AI

**Document Version:** 1.0 (Finalized Blueprint)  
**Related Docs:** [PROJECT_SCHEMA.md](file:///d:/Loan%20prediction/PROJECT_SCHEMA.md) | [docs/API_SPECIFICATION.md](file:///d:/Loan%20prediction/docs/API_SPECIFICATION.md) | [docs/ML_METHODOLOGY.md](file:///d:/Loan%20prediction/docs/ML_METHODOLOGY.md)

---

## 1. Architectural Principles

LoanWise AI follows a **decoupled two-workflow architecture** suitable for a first-year AI & ML team:

1. **Strict Separation of Offline Training and Online Inference:**
   - The ML pipeline is trained, evaluated, and serialized **offline** (`ml/train.py` + `ml/evaluate.py`).
   - The FastAPI backend **never** retrains the model on incoming user requests; it loads the frozen serialized pipeline (`models/model_pipeline.joblib`) once at startup.
2. **Single Source of Truth for Preprocessing:**
   - All imputation, encoding, scaling, and feature engineering live inside a scikit-learn `Pipeline` + `ColumnTransformer` so training and prediction apply identical transformations without training-serving skew.
3. **Lightweight, Explainable, Zero-Bloat Stack:**
   - No Docker orchestration, Redis, message queues, or microservices are added because they provide zero educational or functional necessity for a local 3-student capstone demo.

---

## 2. High-Level System Architecture Diagram

```mermaid
flowchart TB
    subgraph Offline["Offline ML Training Workflow (Run Before Serving)"]
        RAW["Raw Kaggle CSV\ndata/raw/train.csv"] --> INSP["Inspection & EDA\nnotebooks/"]
        INSP --> SPLIT["Stratified Train/Test Split\n(ML Pipeline)"]
        SPLIT --> PIPE["Scikit-learn Pipeline\n(Feature Eng + ColumnTransformer + Classifier)"]
        PIPE --> EVAL["Cross-Validation & Held-Out Evaluation\n(Metrics + Fairness Check)"]
        EVAL --> ART["Serialized Artifacts\nmodels/model_pipeline.joblib\nmodels/model_metadata.json\nmodels/shap_background.joblib"]
    end

    subgraph Online["Online Application Workflow (Runtime Serving)"]
        USER["Student / Evaluator Browser"] --> ST["Streamlit Frontend\n(6 Pages + Plotly + Custom CSS)"]
        ST -->|"HTTP JSON (REST)"| API["FastAPI Backend\n(Pydantic Validation + Routers)"]
        API -->|"Load at Startup"| ART
        API -->|"Predict & Probability"| INF["Inference Service\n(backend/services/predictor.py)"]
        API -->|"Feature Contributions"| EXP["SHAP Explainability Service\n(backend/services/explainer.py)"]
        API -->|"Store & Query Non-PII Logs"| DB[("SQLite Database\ndatabase/loanwise.db")]
    end
```

---

## 3. Offline Machine Learning Workflow Diagram

```mermaid
flowchart LR
    A["1. Load Primary CSV"] --> B["2. Schema & Missing/Duplicate Checks"]
    B --> C["3. EDA & Outlier Inspection"]
    C --> D["4. Stratified Split (80% Dev / 20% Test)"]
    D --> E["5. Build Preprocessing + Feature Eng Pipeline"]
    E --> F["6. 5-Fold Stratified CV on Dev Set"]
    F --> G["7. Compare LogReg, DecisionTree, RandomForest"]
    G --> H["8. Optional Bounded Tuning on CV Only"]
    H --> I["9. Final Evaluation on 20% Held-Out Test"]
    I --> J["10. Fairness Ablation & SHAP Verification"]
    J --> K["11. Export Pipeline, Metadata & SHAP Background"]
```

---

## 4. Online Prediction & Explainability Sequence Diagram

```mermaid
sequenceDiagram
    actor User as User (Browser)
    participant UI as Streamlit Frontend
    participant API as FastAPI Backend
    participant Val as Pydantic Validator
    participant Model as Loaded Sklearn Pipeline
    participant SHAP as SHAP Explainer Service
    participant DB as SQLite (loanwise.db)

    User->>UI: Fill 11 applicant fields & click "Assess Eligibility"
    UI->>UI: Client-side range checks
    UI->>API: POST /predict (JSON applicant payload)
    API->>Val: Validate types, categories & bounds
    alt Invalid Input
        Val-->>API: ValidationError
        API-->>UI: HTTP 422 Unprocessable Entity (structured error)
        UI-->>User: Show clear field-level validation message
    else Valid Input
        Val-->>API: Validated ApplicantInput
        API->>Model: predict() and predict_proba()
        Model-->>API: Class (0/1) & approval probability p
        API->>API: Compute risk band & human-review flag (0.40 <= p <= 0.60)
        API->>DB: Insert non-PII assessment record
        DB-->>API: assessment_id
        API-->>UI: HTTP 200 PredictionResponse
        UI-->>User: Display Result, Probability Gauge & Disclaimer

        User->>UI: Open "Explainable AI" tab or click "Explain Prediction"
        UI->>API: POST /explain (JSON applicant payload)
        API->>SHAP: Transform features & compute SHAP values
        SHAP-->>API: Base value, per-feature contributions, top drivers
        API-->>UI: HTTP 200 ExplainResponse
        UI-->>User: Render Plotly SHAP Waterfall/Bar + Plain Summary
    end
```

---

## 5. Component Responsibilities

### 5.1 Frontend Layer (`frontend/`)
- **Streamlit (`app.py` + `pages/`):** Provides multi-page navigation across Dashboard, Loan Eligibility Assessment, Prediction Results, Explainable AI, Assessment History, and Model Information.
- **Custom CSS (`frontend/assets/styles.css`):** Ensures clean typography, readable metric cards, status badges (`Approved`, `Rejected`, `Review Recommended`), and consistent spacing.
- **Plotly (`plotly.graph_objects` / `plotly.express`):** Renders interactive probability gauges, SHAP positive/negative horizontal bar charts, and dataset/metric visualizations.
- **API Client (`frontend/services/api_client.py`):** Centralizes HTTP calls to FastAPI with timeout handling and friendly connection-error banners if the backend is offline.

### 5.2 Backend Layer (`backend/`)
- **FastAPI (`backend/main.py`):** Initializes the application, configures CORS for local Streamlit access, loads the serialized ML model and metadata via lifespan hooks, and mounts route handlers.
- **Pydantic Schemas (`backend/schemas/`):** Enforces exact types, allowed category literals, and numeric bounds matching the trained dataset schema.
- **Inference & Explainability Services (`backend/services/`):**
  - `model_loader.py`: Loads `models/model_pipeline.joblib`, `models/model_metadata.json`, and `models/shap_background.joblib` once at startup.
  - `predictor.py`: Converts validated request to a single-row DataFrame with exact training column order, computes prediction + approval probability, assigns risk tier and borderline human-review flag.
  - `explainer.py`: Extracts the fitted preprocessor and classifier from the pipeline, transforms the input, computes SHAP values, and aggregates one-hot encoded contributions back to the original human-readable input features (e.g., summing `Property_Area_Urban`, `Property_Area_Rural`, `Property_Area_Semiurban` or reporting the active category's contribution cleanly).

### 5.3 Machine Learning Layer (`ml/` & `notebooks/`)
- **Jupyter Notebooks (`notebooks/`):** Interactive EDA, missing-value visualization, outlier checks, and supplementary dataset compatibility check.
- **Python Modules (`ml/`):** Reproducible scripts (`preprocess.py`, `train.py`, `evaluate.py`, `explain.py`, `fairness.py`) so model training can be re-executed in one command without manual notebook cell ordering errors.

### 5.4 Storage Layer (`database/` & `models/`)
- **SQLite (`database/loanwise.db`):** Single-file embedded relational database storing anonymous assessment logs (`id`, timestamp, input features excluding any PII, prediction, probability, model version). Zero external DB server needed.
- **Model Artifacts (`models/`):** Binary `.joblib` pipeline + JSON metadata file inspected by `GET /model-info` and the Streamlit Model Information page.

---

## 6. Technology Selection Justification

| Choice | Why Selected | Alternatives Rejected & Why |
| :--- | :--- | :--- |
| **Streamlit** | Rapid Python-native UI, built-in multi-page support, ideal for first-year ML teams | React/Next.js (adds JS/Node complexity unrelated to ML learning goals) |
| **Plotly** | Interactive tooltips and clean horizontal SHAP / gauge charts inside Streamlit | Matplotlib-only (static images, harder to style cleanly for web dashboards) |
| **FastAPI + Pydantic** | Automatic OpenAPI docs (`/docs`), strict runtime validation, clean separation from UI | Putting ML directly inside Streamlit (couples UI and model logic; prevents API testing) |
| **Scikit-learn** | Industry-standard `Pipeline` & `ColumnTransformer`, prevents data leakage, lightweight | Deep Learning / PyTorch (overkill and prone to overfitting on ~614 tabular rows) |
| **SHAP** | Principled local and global feature attributions compatible with linear and tree models | LIME-only (less consistent across repeated calls on tabular data) |
| **SQLite** | Zero-config built-in Python database (`sqlite3`), persistent history for demo | PostgreSQL / MongoDB (unnecessary server setup for local capstone demo) |
| **Joblib** | Efficient serialization for scikit-learn pipelines and NumPy arrays | Pickle raw (less efficient for large NumPy arrays inside Random Forests) |
