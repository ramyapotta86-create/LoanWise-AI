# FOLDER STRUCTURE — LOANWISE AI

**Document Version:** 1.0 (Finalized Blueprint)  
**Related Docs:** [PROJECT_SCHEMA.md](file:///d:/Loan%20prediction/PROJECT_SCHEMA.md) | [docs/GITHUB_WORKFLOW.md](file:///d:/Loan%20prediction/docs/GITHUB_WORKFLOW.md) | [docs/IMPLEMENTATION_ROADMAP.md](file:///d:/Loan%20prediction/docs/IMPLEMENTATION_ROADMAP.md)

> **Blueprint Note:** This document defines the finalized target repository layout. Only the root documentation (`README.md`, `PROJECT_SCHEMA.md`) and `docs/*.md` exist at this blueprint stage; code folders and runtime artifacts will be created starting in Phase 1.

---

## 1. Complete Repository Layout

```text
loanwise-ai/
├── README.md                              # Project entry point, overview & quick-start guide
├── PROJECT_SCHEMA.md                      # Master project schema & cross-doc index
├── requirements.txt                       # Pinned Python dependencies (created in Phase 1)
├── .gitignore                             # Excludes raw CSVs, models, DB, venv, caches
├── .env.example                           # Sample runtime configuration variables
│
├── config/
│   └── settings.py                        # Shared paths, API URL, threshold & review-band constants
│
├── data/
│   ├── README.md                          # Kaggle download instructions, source URLs & checksums
│   ├── raw/                               # [GIT-IGNORED] Original downloaded Kaggle CSV files
│   └── processed/                         # [GIT-IGNORED] Verified train/test split summaries or cleaned exports
│
├── notebooks/
│   ├── 01_data_inspection.ipynb           # Schema, row counts, duplicates & dtype verification
│   ├── 02_eda_visualization.ipynb         # Missing values, outliers, distributions & target balance
│   ├── 03_model_experiments.ipynb         # Scratchpad for CV experiments & SHAP checks
│   └── 04_supplementary_dataset_experiment.ipynb  # Optional isolated check of architsharma01 dataset
│
├── ml/
│   ├── __init__.py
│   ├── preprocess.py                      # FeatureEngineerTransformer + ColumnTransformer builder
│   ├── train.py                           # Stratified split, 5-fold CV, model selection & joblib export
│   ├── evaluate.py                        # Accuracy, Precision, Recall, F1, ROC-AUC & Confusion Matrix
│   ├── explain.py                         # SHAP explainer builder & one-hot feature aggregation helper
│   └── fairness.py                        # Demographic ablation (with/without Gender & Married) + DPD/EOD
│
├── models/                                # [GIT-IGNORED binaries; README tracked]
│   ├── README.md                          # How to regenerate model artifacts via `python -m ml.train`
│   ├── model_pipeline.joblib              # [GIT-IGNORED] Serialized preprocessing + winning classifier
│   ├── shap_background.joblib             # [GIT-IGNORED] Background sample for SHAP explainer
│   └── model_metadata.json                # [Tracked or generated] Metrics, version, feature list & config
│
├── backend/
│   ├── __init__.py
│   ├── main.py                            # FastAPI app initialization, lifespan loader & CORS
│   ├── routers/
│   │   ├── __init__.py
│   │   ├── health.py                      # GET /
│   │   ├── predict.py                     # POST /predict
│   │   ├── explain.py                     # POST /explain
│   │   ├── history.py                     # GET /history
│   │   └── model_info.py                  # GET /model-info
│   ├── schemas/
│   │   ├── __init__.py
│   │   ├── loan.py                        # LoanApplicationRequest & PredictionResponse Pydantic models
│   │   ├── explain.py                     # ExplainResponse & FeatureContribution models
│   │   └── history.py                     # HistoryResponse & AssessmentRecord models
│   └── services/
│       ├── __init__.py
│       ├── model_loader.py                # Startup loader for joblib pipeline, SHAP background & metadata
│       ├── predictor.py                   # Prediction logic, confidence band & review flag
│       ├── explainer.py                   # SHAP calculation & human-readable explanation builder
│       └── history_store.py               # SQLite read/write operations (non-PII only)
│
├── database/
│   ├── __init__.py
│   ├── db.py                              # SQLite connection & table initialization
│   └── loanwise.db                        # [GIT-IGNORED] Local runtime SQLite database file
│
├── frontend/
│   ├── app.py                             # Page 1: Dashboard (entry point for `streamlit run`)
│   ├── assets/
│   │   └── styles.css                     # Custom CSS for cards, badges & layout polish
│   ├── components/
│   │   └── disclaimers.py                 # Reusable educational prototype & causation disclaimers
│   ├── services/
│   │   └── api_client.py                  # HTTP client wrapping FastAPI endpoints
│   └── pages/
│       ├── 1_Loan_Assessment.py           # Page 2: 11-field applicant eligibility form
│       ├── 2_Prediction_Results.py        # Page 3: Decision, probability gauge & review banner
│       ├── 3_Explainable_AI.py            # Page 4: SHAP waterfall/bar chart & plain-English drivers
│       ├── 4_Assessment_History.py        # Page 5: Filterable SQLite assessment log table
│       └── 5_Model_Information.py         # Page 6: Model metrics, comparison table & Responsible AI
│
├── tests/
│   ├── __init__.py
│   ├── test_ml_pipeline.py                # Preprocessing, Dependents "3+" mapping, TotalIncome & leak checks
│   ├── test_api.py                        # FastAPI TestClient checks for all 5 endpoints & 422 validation
│   └── test_database.py                   # SQLite insert/filter/non-PII schema tests
│
└── docs/
    ├── SYSTEM_ARCHITECTURE.md
    ├── DATASET_STRATEGY.md
    ├── ML_METHODOLOGY.md
    ├── API_SPECIFICATION.md
    ├── FOLDER_STRUCTURE.md
    ├── TEAM_RESPONSIBILITIES.md
    ├── GITHUB_WORKFLOW.md
    ├── IMPLEMENTATION_ROADMAP.md
    └── RESPONSIBLE_AI.md
```

---

## 2. Git-Ignored Files & Team Setup Instructions

To keep the GitHub repository clean and avoid licensing/binary bloat:
1. **Ignored via `.gitignore`:**
   - `data/raw/*.csv`, `data/processed/*.csv`
   - `models/*.joblib` (and optionally `*.pkl`)
   - `database/*.db`, `database/*.sqlite`
   - `.venv/`, `venv/`, `__pycache__/`, `.pytest_cache/`, `.ipynb_checkpoints/`, `.env`
2. **How Team Members Obtain Required Local Files:**
   - **Datasets:** Follow `data/README.md` to download the Kaggle CSVs directly from Kaggle into `data/raw/` and verify file hashes.
   - **Model Artifacts:** Run `python -m ml.train` from the project root after placing the primary CSV in `data/raw/`. This deterministically regenerates `models/model_pipeline.joblib`, `models/shap_background.joblib`, and `models/model_metadata.json`.
   - **Database:** Automatically initialized on first FastAPI startup (`database/db.py`).

---

## 3. Planned `.gitignore` Specification (Create in Phase 1)

```gitignore
# Python environments & caches
.venv/
venv/
__pycache__/
*.py[cod]
.pytest_cache/
.ipynb_checkpoints/

# Environment variables
.env

# Raw & processed datasets
data/raw/*.csv
data/processed/*.csv

# Serialized model binaries
models/*.joblib
models/*.pkl

# Local SQLite database
database/*.db
database/*.sqlite

# OS / IDE artifacts
.DS_Store
Thumbs.db
.vscode/
```

---

## 4. Planned `requirements.txt` Core Dependencies (Create in Phase 1)

Keep dependencies minimal, stable, and Python 3.10+ compatible:
- `pandas`
- `numpy`
- `scikit-learn`
- `shap`
- `joblib`
- `fastapi`
- `uvicorn[standard]`
- `pydantic`
- `streamlit`
- `plotly`
- `requests`
- `pytest`
- `httpx` *(required by FastAPI `TestClient`)*
- `jupyter` *(or `ipykernel` for notebook execution)*
