# DATASET STRATEGY — LOANWISE AI

**Document Version:** 1.0 (Finalized Blueprint)  
**Related Docs:** [PROJECT_SCHEMA.md](file:///d:/Loan%20prediction/PROJECT_SCHEMA.md) | [docs/ML_METHODOLOGY.md](file:///d:/Loan%20prediction/docs/ML_METHODOLOGY.md) | [docs/RESPONSIBLE_AI.md](file:///d:/Loan%20prediction/docs/RESPONSIBLE_AI.md)

> **Verification Status:** Neither Kaggle dataset has been downloaded or locally inspected in `d:\Loan prediction` yet. All row counts, filenames, and column lists below reflect **publicly listed Kaggle/source metadata** and are marked **Pending Local Verification** until Phase 2 inspection is completed.

---

## 1. Primary Dataset Specification (Assigned Foundation)

- **Title:** Loan Prediction Problem Dataset
- **Platform & Author:** Kaggle (`altruistdelhite04/loan-prediction-problem-dataset`), originally derived from an Analytics Vidhya practice competition.
- **URL:** https://www.kaggle.com/datasets/altruistdelhite04/loan-prediction-problem-dataset
- **Publicly Listed Files & Dimensions *(Pending Local CSV Verification)*:**
  - Training CSV (commonly `train_u6lujuX_CVtuZ9i.csv` or `train.csv`): ~614 records × 13 columns (11 usable features + `Loan_ID` + `Loan_Status`).
  - Testing CSV (commonly `test_Y3wMUE5_7gLdaTN.csv` or `test.csv`): ~367 records × 12 columns (no `Loan_Status` target column).
- **Publicly Listed License:** Copyright / All Rights Reserved (shared on Kaggle for educational practice). Confirm exact license/terms on the Kaggle dataset page before final submission.

### 1.1 Primary Schema & Feature Roles

| # | Column Name | Expected Type | Expected Values / Domain *(Verify Locally)* | Role in LoanWise AI |
| :--- | :--- | :--- | :--- | :--- |
| 1 | `Loan_ID` | String | Unique ID (`LP001002`, etc.) | **Excluded** from training, API, and SQLite (non-predictive identifier) |
| 2 | `Gender` | Categorical | `Male`, `Female` | Input feature + Responsible AI audit |
| 3 | `Married` | Categorical | `Yes`, `No` | Input feature + Responsible AI audit |
| 4 | `Dependents` | Categorical / Ordinal | `0`, `1`, `2`, `3+` | Input feature (`"3+"` mapped to `3` in pipeline) |
| 5 | `Education` | Categorical | `Graduate`, `Not Graduate` | Input feature |
| 6 | `Self_Employed` | Categorical | `Yes`, `No` | Input feature |
| 7 | `ApplicantIncome` | Numerical | Non-negative income *(verify monthly vs. other period)* | Input feature + `TotalIncome` |
| 8 | `CoapplicantIncome` | Numerical | Non-negative income *(verify unit matches ApplicantIncome)* | Input feature + `TotalIncome` |
| 9 | `LoanAmount` | Numerical | Positive loan amount *(commonly in thousands — verify scale)* | Input feature |
| 10 | `Loan_Amount_Term` | Numerical | Term in months (commonly `360`, `180`, etc.) | Input feature |
| 11 | `Credit_History` | Binary Numeric | `1` (meets credit guidelines), `0` (does not) | Input feature |
| 12 | `Property_Area` | Categorical | `Urban`, `Semiurban`, `Rural` *(verify exact spelling)* | Input feature |
| 13 | `Loan_Status` | Target (Train only) | `Y` (Approved → `1`), `N` (Rejected → `0`) | Supervised binary target |

### 1.2 Why the Kaggle Test File Cannot Evaluate Model Metrics
Because the ~367-row Kaggle test CSV does **not** contain `Loan_Status`, it cannot be used to compute accuracy, precision, recall, F1, or ROC-AUC. All model validation and held-out test metrics must come from a **stratified split of the ~614 labeled training records**.

---

## 2. Supplementary Dataset Evaluation

- **Candidate Title:** Loan Approval Prediction Dataset
- **Platform & Author:** Kaggle (`architsharma01/loan-approval-prediction-dataset`)
- **URL:** https://www.kaggle.com/datasets/architsharma01/loan-approval-prediction-dataset
- **Publicly Listed Metadata *(Pending Local CSV Verification)*:**
  - ~4,269 records × 13 columns (`loan_id`, `no_of_dependents`, `education`, `self_employed`, `income_annum`, `loan_amount`, `loan_term`, `cibil_score`, `residential_assets_value`, `commercial_assets_value`, `luxury_assets_value`, `bank_asset_value`, `loan_status`).
  - Publicly listed under the **MIT License**.

### 2.1 Seven-Criterion Compatibility Audit

| Criterion | Primary (`altruistdelhite04`) | Supplementary (`architsharma01`) | Compatibility Verdict |
| :--- | :--- | :--- | :--- |
| **1. Target variable meaning** | `Loan_Status` (`Y` / `N`) | `loan_status` (`Approved` / `Rejected`) | Conceptually similar, but synthetic/collection rules may differ |
| **2. Feature definitions** | Binary `Credit_History` (`0/1`), `Property_Area`, `Gender`, `Married`, `CoapplicantIncome` | Continuous `cibil_score` (~300–900), 4 asset columns, no `Gender`/`Married`/`Property_Area`/`CoapplicantIncome` | **Incompatible** — core credit and demographic/asset features do not align |
| **3. Financial units & periods** | `ApplicantIncome` & `CoapplicantIncome` (commonly monthly), `LoanAmount` (commonly thousands) | `income_annum` (annual), `loan_amount` (full currency units), `loan_term` (verify years vs. months locally) | **Incompatible without unverifiable assumptions** |
| **4. Overlapping / duplicate records** | 614 historical/competition rows | 4,269 rows with distinct schema | Unlikely row overlap, but schema mismatch prevents union |
| **5. Collection process & bias** | Older retail home-loan style dataset with missing values | Likely synthetic/simulated Indian retail loan dataset with zero missing values (verify locally) | **Different data-generating processes** |
| **6. Measurable project improvement** | Merging would force dropping/imputing `Gender`, `Married`, `Property_Area`, `cibil_score`, and all 4 asset features | — | **Degrades fidelity** rather than improving it |
| **7. Source & license** | Kaggle educational practice dataset | MIT License | License is permissive, but technical incompatibility blocks merging |

---

## 3. Final Dataset Decision

1. **Primary Foundation Only for Production Model:**  
   Train the LoanWise AI production pipeline **exclusively on the assigned primary dataset** (`altruistdelhite04/loan-prediction-problem-dataset`).
2. **Strict No-Merge Rule:**  
   **Do NOT merge** `altruistdelhite04` and `architsharma01`. Fabricating missing columns (e.g., guessing `cibil_score` from binary `Credit_History`, or synthesizing `Gender`/`Married`/`Property_Area` or asset values) is scientifically invalid and prohibited.
3. **Optional Separate Comparative Experiment:**  
   If time permits after Phase 9, Member 1 may run `architsharma01/loan-approval-prediction-dataset` in an **isolated notebook** (`notebooks/04_supplementary_dataset_experiment.ipynb`) after downloading and verifying its CSV columns/units/missingness, strictly to compare how a larger, asset-rich dataset behaves versus the 614-row primary dataset in the final presentation. It will **not** feed the FastAPI/Streamlit app.

---

## 4. Mandatory Local Verification Checklist (Phase 2)

Before writing `ml/preprocess.py`, Member 1 must download the primary CSVs into `data/raw/` and execute an inspection script/notebook (`notebooks/01_data_inspection.ipynb`) verifying:

- [ ] Exact file names, file sizes, and UTF-8 encoding.
- [ ] Exact row and column counts of both train and test CSVs.
- [ ] Exact column names (checking for leading/trailing spaces or casing differences).
- [ ] Exact unique values in categorical columns (`Semiurban` vs `Semi-Urban`, `3+`, whitespace).
- [ ] Missing-value count and percentage per column in both train and test sets.
- [ ] Exact duplicate row count (`df.duplicated().sum()`) and duplicate `Loan_ID` check.
- [ ] Value ranges and scale check for `ApplicantIncome`, `CoapplicantIncome`, `LoanAmount`, and `Loan_Amount_Term` (confirming whether `LoanAmount` is in thousands and `ApplicantIncome` is monthly).
- [ ] Class balance of `Loan_Status` (`Y` vs `N`).
- [ ] SHA-256 checksums / download timestamp recorded in `data/README.md` so all 3 team members use identical raw files.
