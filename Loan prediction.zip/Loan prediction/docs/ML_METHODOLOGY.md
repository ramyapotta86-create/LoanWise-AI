# MACHINE LEARNING METHODOLOGY — LOANWISE AI

**Document Version:** 1.0 (Finalized Blueprint)  
**Related Docs:** [PROJECT_SCHEMA.md](file:///d:/Loan%20prediction/PROJECT_SCHEMA.md) | [docs/DATASET_STRATEGY.md](file:///d:/Loan%20prediction/docs/DATASET_STRATEGY.md) | [docs/RESPONSIBLE_AI.md](file:///d:/Loan%20prediction/docs/RESPONSIBLE_AI.md)

> **Experimental Integrity Notice:** No training has been run yet. No model is declared "best" in advance, and all metric tables below use `TBD` placeholders until Phase 5 experimentation is executed and logged.

---

## 1. End-to-End 16-Step Supervised Classification Pipeline

| Step | Stage | Implementation Target |
| :--- | :--- | :--- |
| 1 | Dataset loading & inspection | `notebooks/01_data_inspection.ipynb` |
| 2 | Exploratory Data Analysis (EDA) | `notebooks/02_eda_visualization.ipynb` |
| 3 | Missing-value analysis | `notebooks/02_eda_visualization.ipynb` |
| 4 | Duplicate & inconsistent-record checks | `notebooks/01_data_inspection.ipynb` |
| 5 | Outlier analysis (IQR / domain inspection) | `notebooks/02_eda_visualization.ipynb` |
| 6 | Categorical & numerical feature identification | `ml/preprocess.py` |
| 7 | Feature preprocessing (`ColumnTransformer`) | `ml/preprocess.py` |
| 8 | Feature engineering (`TotalIncome`, verified ratios only) | `ml/preprocess.py` |
| 9 | Stratified train-validation-test strategy | `ml/train.py` |
| 10 | Model training (LogReg, Decision Tree, Random Forest) | `ml/train.py` |
| 11 | Model comparison on Stratified CV + Held-Out Test | `ml/evaluate.py` |
| 12 | Bounded hyperparameter tuning (CV only, if justified) | `ml/train.py` |
| 13 | Final evaluation & confusion matrix / FP-FN analysis | `ml/evaluate.py` |
| 14 | Model & metadata serialization (`joblib` + JSON) | `ml/train.py` |
| 15 | Backend REST API serving | `backend/services/predictor.py` |
| 16 | SHAP explainability & interpretation | `ml/explain.py` & `backend/services/explainer.py` |

---

## 2. Data Quality, Missing Values & Outlier Policy

1. **Identifier Removal:** Drop `Loan_ID` before modeling.
2. **Do Not Blanket-Drop Missing Rows:** With only ~614 records, dropping every row with a missing value would discard significant data and introduce selection bias. Instead:
   - Drop rows **only** if the target `Loan_Status` itself is missing or if exact duplicate records exist.
   - Impute missing input values **inside the scikit-learn pipeline** fitted strictly on training folds.
3. **Missing-Value Strategy:**
   - **Numerical features** (`ApplicantIncome`, `CoapplicantIncome`, `LoanAmount`, `Loan_Amount_Term`, `Credit_History`, `Dependents` after mapping `"3+"` → `3`): `SimpleImputer(strategy="median")` (robust to right-skewed incomes/loan amounts). *Note: During EDA, check whether `Credit_History` missing values should use `most_frequent` vs. `median` (for binary `0/1`, median and mode behave similarly unless ties occur; document the final choice after EDA).*
   - **Categorical features** (`Gender`, `Married`, `Education`, `Self_Employed`, `Property_Area`): `SimpleImputer(strategy="most_frequent")`.
4. **Outlier Treatment:**
   - Inspect right-skewed distributions (`ApplicantIncome`, `CoapplicantIncome`, `LoanAmount`) using boxplots and IQR during EDA.
   - Do **not** blindly delete high-income applicants unless confirmed as data-entry errors, because legitimate high-income loans occur in real lending.
   - Evaluate whether `log1p` transformation (e.g., on `TotalIncome` / `LoanAmount` for Logistic Regression) or winsorization/clipping improves CV performance without harming interpretability. Document the verified decision in Phase 4.
5. **Class Imbalance Analysis:**
   - Measure `Loan_Status` (`Y` vs `N`) ratio during EDA.
   - Evaluate `class_weight="balanced"` vs. default weights on Logistic Regression / Random Forest using Stratified CV F1-score and Recall for the minority (`Rejected`) class.

---

## 3. Feature Preprocessing & Feature Engineering (`ml/preprocess.py`)

### 3.1 Leak-Free Pipeline Structure
All transformations run inside a single `sklearn.pipeline.Pipeline`:

```text
Raw 11-Column DataFrame
  └── Step 1: FeatureEngineerTransformer (Stateless FunctionTransformer / BaseEstimator)
        ├── Strip whitespace on string fields
        ├── Map Dependents: "0"->0, "1"->1, "2"->2, "3+"->3 (numeric float/int)
        ├── Compute TotalIncome = ApplicantIncome + CoapplicantIncome
        └── [Optional, ONLY if EDA confirms matching units] Additional verified ratio
  └── Step 2: ColumnTransformer
        ├── Numerical Pipeline:
        │     ├── SimpleImputer(strategy="median")
        │     └── StandardScaler()  [enabled for LogisticRegression; pass-through or scaled for trees]
        └── Categorical Pipeline:
              ├── SimpleImputer(strategy="most_frequent")
              └── OneHotEncoder(handle_unknown="ignore", sparse_output=False)
  └── Step 3: Classifier (LogisticRegression / DecisionTreeClassifier / RandomForestClassifier)
```

### 3.2 Feature Engineering Guardrails
- **Approved Feature:** `TotalIncome = ApplicantIncome + CoapplicantIncome` (same income units and period, captures household repayment capacity).
- **Conditional Features (Require EDA Unit Verification):** Any ratio such as `LoanAmount_to_TotalIncome` may only be added if EDA verifies the unit relationship (e.g., `LoanAmount` in thousands vs. monthly `TotalIncome`) and CV confirms measurable improvement.
- **Strictly Prohibited:** Do **not** fabricate `annual_income`, `existing_monthly_debt`, `cibil_score`, or `assets_value` because they do not exist in the primary dataset.

---

## 4. Data Splitting, Model Selection & Hyperparameter Tuning

### 4.1 Stratified Split & Validation Strategy
Because the Kaggle test CSV (~367 rows) has no labels:
1. Perform an **80% Development / 20% Held-Out Test** split on the labeled training CSV using `train_test_split(..., stratify=y, random_state=42)`.
2. Lock away the **20% Held-Out Test** set until final evaluation (never inspect or tune on it).
3. Inside the **80% Development** set, run **5-Fold Stratified Cross-Validation** (`StratifiedKFold(n_splits=5, shuffle=True, random_state=42)`) to compare algorithms and tune hyperparameters.

### 4.2 Candidate Models
1. **Logistic Regression (`LogisticRegression`):** Simple, linear, natively interpretable baseline; requires feature scaling (`StandardScaler`).
2. **Decision Tree (`DecisionTreeClassifier`):** Non-linear rule-based baseline; requires `max_depth` / `min_samples_leaf` regularization to avoid memorizing 614 rows.
3. **Random Forest (`RandomForestClassifier`):** Variance-reduced ensemble baseline; tune small, sensible grids (e.g., `n_estimators`, `max_depth`, `min_samples_split`, `min_samples_leaf`).

### 4.3 Selection Criteria
Choose the final model holistically using:
- **Primary Quantitative Criterion:** Mean 5-Fold Stratified CV **F1-score** and **ROC-AUC** (verified on the 20% held-out test set without overfitting gap).
- **Secondary Criteria:** Generalization gap (`Train Score - CV Score`), SHAP compatibility/stability, and explainability to non-technical reviewers.

---

## 5. Evaluation Metrics & Error Cost Interpretation

### 5.1 Required Metrics
- **Accuracy** — Overall fraction of correct predictions (insufficient alone if classes are imbalanced).
- **Precision** — Of applications predicted `Approved`, how many were actually `Y`.
- **Recall** — Of actual `Y` applications, how many the model correctly `Approved` (also track per-class Precision/Recall for `Rejected` / `N`).
- **F1-score** — Harmonic mean of Precision and Recall.
- **Confusion Matrix** — `[TN, FP; FN, TP]`.
- **ROC-AUC** — Threshold-independent ranking quality using predicted probabilities.

### 5.2 Business Context of False Positives vs. False Negatives
- **False Positive (FP — Model predicts `Approved`, ground truth `Rejected`):** High financial risk; corresponds to approving an applicant likely to default or fail underwriting guidelines.
- **False Negative (FN — Model predicts `Rejected`, ground truth `Approved`):** Opportunity cost & fairness concern; corresponds to wrongly turning away a creditworthy applicant.
- Both error types justify adding a **human-review confidence band** (`0.40 <= p <= 0.60`) rather than treating automated predictions as final decisions.

### 5.3 Model Comparison Table Template *(Populate in Phase 5)*

| Model | CV Accuracy (Mean ± SD) | CV F1 (Mean ± SD) | CV ROC-AUC (Mean ± SD) | Test Accuracy | Test Precision | Test Recall | Test F1 | Test ROC-AUC | Overfitting Gap |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| Logistic Regression | TBD | TBD | TBD | TBD | TBD | TBD | TBD | TBD | TBD |
| Decision Tree | TBD | TBD | TBD | TBD | TBD | TBD | TBD | TBD | TBD |
| Random Forest | TBD | TBD | TBD | TBD | TBD | TBD | TBD | TBD | TBD |

---

## 6. Model Serialization & Artifacts (`models/`)

After selecting the winning pipeline and refitting on the 80% development set (and verifying on the 20% held-out test set):
1. `models/model_pipeline.joblib` — Complete fitted scikit-learn `Pipeline` (`FeatureEngineer` → `ColumnTransformer` → `Classifier`).
2. `models/shap_background.joblib` — Compact representative sample (e.g., 100 preprocessed training rows or `shap.sample` summary) needed by `LinearExplainer` / fallback `KernelExplainer` at API startup.
3. `models/model_metadata.json` — Version, training timestamp, dataset row counts, feature schema, selected hyperparameters, all model comparison metrics, confusion matrix, and global feature importance.

---

## 7. Explainable AI (SHAP) Design

- **Explainer Selection:**
  - If `RandomForestClassifier` or `DecisionTreeClassifier` is selected → `shap.TreeExplainer` on the classifier using transformed features from the fitted preprocessor.
  - If `LogisticRegression` is selected → `shap.LinearExplainer` on the classifier using transformed background data.
- **One-Hot Aggregation:** Because `OneHotEncoder` splits `Property_Area` into 3 binary columns, sum the SHAP values of a categorical variable's one-hot columns into one clean attribution per original input feature (`Property_Area`, `Education`, etc.) before sending to the frontend.
- **Interpretation Boundary:** Explicitly label SHAP values as **model feature attributions relative to the training dataset baseline**, never as proof of real-world bank causation.
