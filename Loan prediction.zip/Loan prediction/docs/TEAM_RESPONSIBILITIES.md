# TEAM RESPONSIBILITIES — LOANWISE AI

**Document Version:** 1.0 (Finalized Blueprint)  
**Team Size:** 3 Official First-Year AI & ML Students  
**Related Docs:** [PROJECT_SCHEMA.md](file:///d:/Loan%20prediction/PROJECT_SCHEMA.md) | [docs/GITHUB_WORKFLOW.md](file:///d:/Loan%20prediction/docs/GITHUB_WORKFLOW.md) | [docs/IMPLEMENTATION_ROADMAP.md](file:///d:/Loan%20prediction/docs/IMPLEMENTATION_ROADMAP.md)

---

## 1. Division of Ownership (Balanced 3-Member Split)

Every module has one **Primary Owner** (writes the implementation) and one **Peer Reviewer** (reviews PRs and tests functionality), ensuring balanced Git commits and shared understanding across the whole team.

### Member 1 — Data Exploration & Machine Learning Lead
- **Primary Folders:** `data/`, `notebooks/`, `ml/`, `models/`
- **Core Deliverables:**
  1. Download and verify the primary Kaggle dataset (`01_data_inspection.ipynb`, `data/README.md`).
  2. Perform EDA: missingness, duplicates, outliers, class balance (`02_eda_visualization.ipynb`).
  3. Build leak-free preprocessing and `TotalIncome` engineering (`ml/preprocess.py`).
  4. Implement stratified CV training & comparison across Logistic Regression, Decision Tree, and Random Forest (`ml/train.py`, `ml/evaluate.py`).
  5. Run SHAP verification (`ml/explain.py`) and Responsible AI demographic ablation (`ml/fairness.py`).
  6. Generate `model_pipeline.joblib`, `shap_background.joblib`, and `model_metadata.json`.
  7. *(Optional)* Run isolated supplementary dataset comparison (`04_supplementary_dataset_experiment.ipynb`).
- **Primary Peer Reviewer For:** Member 2's ML service integration (`backend/services/predictor.py`, `explainer.py`).

---

### Member 2 — Backend API, Explainability Service & Database Lead
- **Primary Folders:** `backend/`, `database/`, `config/`
- **Core Deliverables:**
  1. Implement shared configuration (`config/settings.py`) and `.env.example`.
  2. Implement SQLite schema & non-PII CRUD layer (`database/db.py`, `backend/services/history_store.py`).
  3. Implement startup model loader (`backend/services/model_loader.py`).
  4. Implement inference & confidence/review-band logic (`backend/services/predictor.py`).
  5. Implement SHAP API wrapper with one-hot aggregation & plain-language summary (`backend/services/explainer.py`).
  6. Build Pydantic schemas (`backend/schemas/*.py`) and all 5 FastAPI endpoints (`GET /`, `POST /predict`, `POST /explain`, `GET /history`, `GET /model-info`).
  7. Ensure clean `422`, `503`, and `500` error handling and Swagger `/docs` verification.
- **Primary Peer Reviewer For:** Member 3's API client (`frontend/services/api_client.py`) and Member 1's `ml/explain.py`.

---

### Member 3 — Frontend UI, Visualizations & Full-Stack Integration Lead
- **Primary Folders:** `frontend/`
- **Core Deliverables:**
  1. Design clean Streamlit layout and custom CSS (`frontend/assets/styles.css`) + reusable disclaimers (`frontend/components/disclaimers.py`).
  2. Build resilient FastAPI HTTP client (`frontend/services/api_client.py`).
  3. Build Page 1: **Dashboard** (`frontend/app.py`).
  4. Build Page 2: **Loan Eligibility Assessment** (`1_Loan_Assessment.py`) with exact 11 model-supported inputs and validation hints.
  5. Build Page 3: **Prediction Results** (`2_Prediction_Results.py`) with Plotly probability gauge and borderline human-review alert.
  6. Build Page 4: **Explainable AI** (`3_Explainable_AI.py`) with Plotly SHAP positive/negative bar chart and plain-English explanation.
  7. Build Page 5: **Assessment History** (`4_Assessment_History.py`) and Page 6: **Model Information** (`5_Model_Information.py`).
- **Primary Peer Reviewer For:** Member 1's `data/README.md` / EDA clarity and Member 2's API response ergonomics.

---

## 2. Shared Team Responsibilities (All 3 Members)

| Area | Shared Ownership Plan |
| :--- | :--- |
| **Automated Testing (`tests/`)** | Member 1 writes `test_ml_pipeline.py`; Member 2 writes `test_api.py` & `test_database.py`; Member 3 runs end-to-end UI smoke tests and verifies error states. |
| **Documentation (`docs/`)** | Each member updates the docs matching their module after implementation (e.g., Member 1 populates actual CV/test metrics in `ML_METHODOLOGY.md` and `RESPONSIBLE_AI.md`). |
| **GitHub Contributions** | Every member works exclusively on feature branches, writes meaningful commit messages, and reviews at least one PR from another teammate before merging to `develop`. |
| **System Integration** | Jointly execute Phase 8–10 integration testing (ML → FastAPI → Streamlit) before merging `develop` into `main`. |
| **Final Presentation & Viva** | All 3 members jointly build the slide deck and rehearse live demo + Q&A. |

---

## 3. Cross-Training Matrix (Viva & Evaluation Readiness)

During academic evaluation, instructors may ask **any** team member about **any** part of the system. Each member must be able to explain:

| Concept | Member 1 | Member 2 | Member 3 |
| :--- | :---: | :---: | :---: |
| Why `Loan_ID` is excluded & why datasets are not merged | Lead | Must explain | Must explain |
| How `ColumnTransformer` prevents data leakage | Lead | Must explain | Must explain |
| Why offline training is separated from FastAPI inference | Must explain | Lead | Must explain |
| What `POST /predict` & `POST /explain` return and how errors work | Must explain | Lead | Must explain |
| How SHAP attributions differ from real-world causation | Lead | Co-lead | Must explain |
| How Streamlit pages connect to FastAPI & why no PII is stored | Must explain | Must explain | Lead |
