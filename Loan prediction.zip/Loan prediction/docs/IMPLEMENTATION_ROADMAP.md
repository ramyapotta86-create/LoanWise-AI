# IMPLEMENTATION ROADMAP — LOANWISE AI

**Document Version:** 1.0 (Finalized Blueprint)  
**Related Docs:** [PROJECT_SCHEMA.md](file:///d:/Loan%20prediction/PROJECT_SCHEMA.md) | [docs/TEAM_RESPONSIBILITIES.md](file:///d:/Loan%20prediction/docs/TEAM_RESPONSIBILITIES.md) | [docs/GITHUB_WORKFLOW.md](file:///d:/Loan%20prediction/docs/GITHUB_WORKFLOW.md)

---

## 1. Phase Dependency Graph

```mermaid
flowchart TD
    P1["1. Project Setup"] --> P2["2. Dataset Verification"]
    P2 --> P3["3. Dataset Exploration (EDA)"]
    P3 --> P4["4. ML Preprocessing"]
    P4 --> P5["5. Model Training & Evaluation"]
    P1 --> P6["6. Backend API Skeleton & DB"]
    P1 --> P7["7. Frontend UI Skeleton"]
    P5 -->|"Gate 1: model_pipeline.joblib & metadata"| P8["8. Model Integration"]
    P6 --> P8
    P5 --> P9["9. Explainability (SHAP) Integration"]
    P8 --> P9
    P7 --> P10["10. End-to-End Integration & Testing"]
    P9 --> P10
    P10 --> P11["11. Documentation Finalization"]
    P11 --> P12["12. Final Demo Preparation"]
```

*(Phases 6 and 7 can start in parallel right after Phase 1 using the finalized schema in `API_SPECIFICATION.md`, while Phase 8 waits for Phase 5's trained artifacts.)*

---

## 2. Step-by-Step 12-Phase Execution Plan

### Phase 1: Project Setup (All Members)
- **Tasks:** Initialize Git repo (`main` and `develop`), commit `.gitignore`, `requirements.txt`, `.env.example`, `config/settings.py`, and empty package folders (`ml/`, `backend/`, `frontend/`, `database/`, `tests/`, `data/`). Set up Python virtual environments on all 3 machines.
- **Depends On:** Finalized blueprint documents.
- **Definition of Done:** `pip install -r requirements.txt` succeeds on all 3 laptops; `git status` confirms `.venv/` is ignored.

### Phase 2: Dataset Verification (Member 1)
- **Tasks:** Download `altruistdelhite04/loan-prediction-problem-dataset` into `data/raw/`. Run `notebooks/01_data_inspection.ipynb` to confirm exact filenames, row/column counts, column spelling (`Semiurban` vs `Semi-Urban`), missing counts, duplicates, and financial units. Document findings in `data/README.md` and update `docs/DATASET_STRATEGY.md` verification checklist.
- **Depends On:** Phase 1.
- **Definition of Done:** Every team member knows the verified schema and exact target balance; raw CSVs remain git-ignored.

### Phase 3: Dataset Exploration / EDA (Member 1)
- **Tasks:** Build `notebooks/02_eda_visualization.ipynb` covering distributions, missing-value heatmaps, duplicate checks, IQR outlier analysis, `ApplicantIncome` + `CoapplicantIncome` + `LoanAmount` scale checks, and subgroup approval rates across `Credit_History`, `Property_Area`, `Gender`, and `Married`.
- **Depends On:** Phase 2.
- **Definition of Done:** EDA findings directly justify imputation, `"3+"` mapping, outlier policy, and feature engineering choices.

### Phase 4: ML Preprocessing (`feature/data-cleaning`, Member 1)
- **Tasks:** Implement `ml/preprocess.py` with custom stateless transformer (`"3+"` → `3`, whitespace stripping, `TotalIncome`) and `ColumnTransformer` (median numerical imputation, most-frequent categorical imputation, `OneHotEncoder`, `StandardScaler` for linear models). Write `tests/test_ml_pipeline.py` unit tests.
- **Depends On:** Phase 3.
- **Definition of Done:** Preprocessing pipeline transforms training and single-row inference DataFrames identically with zero data leakage.

### Phase 5: Model Training, Evaluation & Fairness (`feature/model-training`, Member 1)
- **Tasks:** Implement `ml/train.py`, `ml/evaluate.py`, `ml/explain.py`, and `ml/fairness.py`. Run 80/20 stratified split + 5-fold CV comparing Logistic Regression, Decision Tree, and Random Forest. Perform bounded tuning on CV only. Run demographic ablation (`Gender`, `Married`). Export `models/model_pipeline.joblib`, `models/shap_background.joblib`, and `models/model_metadata.json`.
- **Depends On:** Phase 4.
- **Definition of Done (**Integration Gate 1**):** Reproducible `python -m ml.train` run completes cleanly; actual measured metrics are recorded in `models/model_metadata.json`.

### Phase 6: Backend API & SQLite Setup (`feature/backend-api`, Member 2)
- **Tasks:** Implement `database/db.py`, `backend/services/history_store.py`, Pydantic schemas (`backend/schemas/`), FastAPI `main.py`, and route skeletons (`GET /`, `GET /history`, `GET /model-info`, `POST /predict`, `POST /explain`).
- **Depends On:** Phase 1 (uses contracts in `API_SPECIFICATION.md`).
- **Definition of Done:** FastAPI starts cleanly, Swagger UI `/docs` renders all 5 endpoints, and SQLite initializes `assessments` table with no PII columns.

### Phase 7: Frontend UI Build (`feature/frontend-ui`, Member 3)
- **Tasks:** Build `frontend/assets/styles.css`, `frontend/components/disclaimers.py`, `frontend/services/api_client.py`, and all 6 Streamlit pages (`Dashboard`, `Loan Assessment`, `Prediction Results`, `Explainable AI`, `Assessment History`, `Model Information`) wired to the API contract.
- **Depends On:** Phase 1 (uses `API_SPECIFICATION.md`).
- **Definition of Done:** All 6 pages navigate cleanly, form inputs match the exact 11 model features, and friendly offline-backend alerts work.

### Phase 8: Model Integration (Member 2 + Member 1)
- **Tasks:** Wire `backend/services/model_loader.py` and `backend/services/predictor.py` to `models/model_pipeline.joblib` and `models/model_metadata.json`. Connect `POST /predict` and `GET /model-info` to real predictions and SQLite persistence.
- **Depends On:** Phase 5 (**Gate 1**) and Phase 6.
- **Definition of Done (**Integration Gate 2**):** `POST /predict` returns real probabilities, borderline review flags (`0.40 <= p <= 0.60`), and persists anonymous history records.

### Phase 9: Explainability Integration (Member 2 + Member 1 + Member 3)
- **Tasks:** Wire `backend/services/explainer.py` to SHAP (`TreeExplainer` / `LinearExplainer`) with one-hot aggregation back to raw feature names. Connect Streamlit `3_Explainable_AI.py` to `POST /explain` and render Plotly SHAP contribution bars + plain-English drivers.
- **Depends On:** Phase 5 and Phase 8.
- **Definition of Done:** Every valid applicant submission produces matching prediction + SHAP waterfall/bar explanation with causation notice.

### Phase 10: Testing & Verification (All Members)
- **Tasks:** Complete `tests/test_ml_pipeline.py`, `tests/test_api.py`, and `tests/test_database.py`. Run full `pytest -v`. Conduct manual end-to-end UI testing across approved, rejected, borderline (`0.40–0.60`), and invalid input cases. Merge `develop` → `main` only after all tests pass.
- **Depends On:** Phase 7, Phase 8, Phase 9.
- **Definition of Done:** 100% of unit and API tests pass; full Streamlit → FastAPI → SQLite flow works seamlessly from `main`.

### Phase 11: Documentation Finalization (All Members)
- **Tasks:** Replace all `TBD` tables in `docs/ML_METHODOLOGY.md` and `docs/RESPONSIBLE_AI.md` with observed CV/test metrics, confusion matrix, and fairness ablation results. Update `README.md` with verified commands and screenshots if helpful.
- **Depends On:** Phase 10.
- **Definition of Done:** Zero inconsistencies between code, API responses, UI labels, and Markdown docs.

### Phase 12: Final Demonstration Preparation (All Members)
- **Tasks:** Prepare final presentation slides (problem statement, dataset decision, ML pipeline, metric comparison, Responsible AI ablation, live demo). Rehearse 3-person handoff and viva Q&A using the cross-training matrix in `TEAM_RESPONSIBILITIES.md`.
- **Depends On:** Phase 11.
- **Definition of Done:** Every team member can run the app locally and explain any component confidently.
